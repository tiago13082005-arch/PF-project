### Which country had the largest water-transport share of national gross value added?

The Netherlands ranked first, Italy second and Portugal third in every year from 2015 through 2024. In 2024 water transport generated €5.026 billion in gross value added (GVA) in Italy and €4.931 billion in the Netherlands. Italy's total economy was larger, so water transport accounted for a smaller share of its national GVA (0.254%) than in the Netherlands (0.493%). Portugal's share was 0.100%. The rankings were stable even when the shares moved sharply. Italy's share, for example, fell from 0.247% in 2019 to 0.110% in 2020 before reaching 0.254% in 2024.

For each country and calendar year we divided water-transport GVA (NACE H50) by all-industry GVA (TOTAL) and multiplied by 100. Both values come from the same national accounts table at current prices in millions of euros. The ranking uses unrounded shares. H50 covers sea, coastal and inland water transport of freight and passengers. This indicator captures the industry's direct contribution. Estimating wider dependence on maritime trade would also require evidence on industries that use shipping.

Source: Eurostat, [Gross value added and income by detailed industry](https://doi.org/10.2908/nama_10_a64), annual frequency, B1G, CP_MEUR, 2015–2024. Source URLs and retrieval timestamps accompany the six snapshots.
