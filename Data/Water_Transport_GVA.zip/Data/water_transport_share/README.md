# Water transport’s share of national GVA

Copy this directory to Data/water_transport_share in the group repository. This analysis uses the same H50, TOTAL, B1G and CP_MEUR selections as the group's nama_10_a64 notebook. The group can add the chart and report paragraph directly to the Results section.

- Open gva_share.png for the chart and ranking_2024.csv for the comparison table.
- Use annual_gva_shares.csv in Flask. Join on country_code and year. The water_share_pct column is already expressed as a percentage (0.493 means 0.493%).
- Run python analyse.py from this directory with pandas and matplotlib installed to reproduce the outputs from the included sources.
- To update from Eurostat, run python refresh.py and then python analyse.py. Review the report paragraph after updating.
