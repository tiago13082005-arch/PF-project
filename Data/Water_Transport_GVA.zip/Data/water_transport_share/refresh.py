"""Retrieve the two annual GVA series for each country from Eurostat."""
import json
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlencode
from urllib.request import urlopen
from concurrent.futures import ThreadPoolExecutor

def fetch(pair):
    country, industry = pair
    filters = dict(freq="A", unit="CP_MEUR", na_item="B1G", nace_r2=industry,
                   geo=country, sinceTimePeriod="2015", untilTimePeriod="2024", lang="EN")
    url = "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_a64?" + urlencode(filters)
    with urlopen(url, timeout=45) as response:
        data = json.load(response)
    for key in ("freq", "unit", "na_item", "nace_r2", "geo"):
        assert list(data["dimension"][key]["category"]["index"]) == [filters[key]]
    return f"{country}_{industry}.json", dict(url=url, retrieved=datetime.now(timezone.utc).isoformat(), data=data)

if __name__ == "__main__":
    pairs = [(country, industry) for country in ("PT", "NL", "IT") for industry in ("H50", "TOTAL")]
    with ThreadPoolExecutor(max_workers=3) as pool:
        snapshots = list(pool.map(fetch, pairs))
    folder = Path(__file__).resolve().parent / "sources"
    folder.mkdir(exist_ok=True)
    for filename, snapshot in snapshots:
        (folder / filename).write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
