"""Build the dashboard data, annual ranks and report figure from saved Eurostat data."""
from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT = Path(__file__).resolve().parent
COUNTRIES = {"PT": "Portugal", "NL": "Netherlands", "IT": "Italy"}

def load_gva(country, industry):
    snapshot = json.loads((ROOT / "sources" / f"{country}_{industry}.json").read_text())
    data = snapshot["data"]
    years = data["dimension"]["time"]["category"]["index"]
    if sorted(map(int, years)) != list(range(2015, 2025)):
        raise ValueError(f"Check year coverage for {country}/{industry}")
    return pd.DataFrame([
        {"year": int(year), industry: data["value"].get(str(position)),
         industry + "_flag": data.get("status", {}).get(str(position), "")}
        for year, position in years.items()
    ])

def calculate():
    tables = []
    for code, name in COUNTRIES.items():
        frame = load_gva(code, "H50").merge(load_gva(code, "TOTAL"), on="year", validate="one_to_one")
        if frame[["H50", "TOTAL"]].isna().any().any() or (frame.TOTAL <= 0).any():
            raise ValueError(f"Check missing values or denominator for {code}")
        frame["country_code"], frame["country"] = code, name
        frame["water_share_pct"] = 100 * frame.H50 / frame.TOTAL
        tables.append(frame)
    panel = pd.concat(tables, ignore_index=True)
    panel["rank"] = panel.groupby("year").water_share_pct.rank(ascending=False, method="min").astype(int)
    return panel.rename(columns={"H50": "water_gva_million_eur", "TOTAL": "total_gva_million_eur"})

def chart(panel):
    fig, ax = plt.subplots(figsize=(8.5, 4.8), layout="constrained")
    for (code, name), color, marker in zip(COUNTRIES.items(), ["#137461","#315785","#ab4932"], ["o","s","^"]):
        series = panel[panel.country_code == code].sort_values("year")
        ax.plot(series.year, series.water_share_pct, label=name, color=color, marker=marker)
    ax.set(title="Water transport’s share of national gross value added", ylabel="Share of total GVA", xlabel="Year")
    ax.yaxis.set_major_formatter(PercentFormatter(xmax=100, decimals=1))
    ax.set_xticks(range(2015, 2025))
    ax.set_ylim(bottom=0)
    ax.grid(axis="y", alpha=.2)
    ax.spines[["top","right"]].set_visible(False)
    ax.legend(ncol=3, frameon=False)
    fig.text(.99, .005, "Source: Eurostat, nama_10_a64 • current prices", ha="right", fontsize=8)
    return fig

if __name__ == "__main__":
    panel = calculate().sort_values(["year", "rank"])
    panel.to_csv(ROOT / "annual_gva_shares.csv", index=False)
    ranking = panel[panel.year == 2024]
    ranking.to_csv(ROOT / "ranking_2024.csv", index=False)
    chart(panel).savefig(ROOT / "gva_share.png", dpi=200, bbox_inches="tight")
    print(ranking.to_string(index=False))
    print(panel.pivot(index="year", columns="country", values="rank"))
