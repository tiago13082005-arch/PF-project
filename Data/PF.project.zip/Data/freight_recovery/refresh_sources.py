"""Refresh the Eurostat source files used by the freight recovery notebook."""
from datetime import datetime, timezone
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen

def refresh():
    folder = Path(__file__).resolve().parent / "sources"
    folder.mkdir(exist_ok=True)
    downloads = {}
    for country in ("PT", "NL", "IT"):
        params = dict(freq="A", direct="TOTAL", unit="THS_T", rep_mar=country,
                      sinceTimePeriod="2015", untilTimePeriod="2025", lang="EN")
        url = "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/mar_go_aa?" + urlencode(params)
        with urlopen(url, timeout=20) as response:
            payload = json.load(response)
        if payload.get("class") != "dataset":
            raise ValueError(f"Unexpected response for {country}")
        downloads[country] = dict(url=url, retrieved_utc=datetime.now(timezone.utc).isoformat(), data=payload)
    for country, snapshot in downloads.items():
        (folder / f"{country}.json").write_text(json.dumps(snapshot, indent=2), encoding="utf-8")

if __name__ == "__main__":
    refresh()
